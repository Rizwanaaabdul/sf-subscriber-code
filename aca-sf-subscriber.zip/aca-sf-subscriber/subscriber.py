import os, json, logging, asyncio
from datetime import datetime
from aiosfstream import SalesforceStreamingClient
from azure.storage.blob import BlobServiceClient

logging.basicConfig(level=logging.INFO)

# ---- Salesforce (set via ACA secrets) ----
SF_CONSUMER_KEY    = os.environ["SF_CONSUMER_KEY"]
SF_CONSUMER_SECRET = os.environ["SF_CONSUMER_SECRET"]
SF_USERNAME        = os.environ["SF_USERNAME"]
SF_PASSWORD        = os.environ["SF_PASSWORD"]     # include the security token
SF_DOMAIN          = os.environ.get("SF_DOMAIN", "login.salesforce.com")
SF_CHANNEL         = os.environ.get("SF_CHANNEL", "/event/YourEvent__e")

# ---- Azure Storage / ADLS Gen2 (Blob SDK works fine for Gen2 containers) ----
AZURE_STORAGE_CONNECTION = os.environ["AZURE_STORAGE_CONNECTION"]
AZURE_CONTAINER          = os.environ.get("AZURE_CONTAINER", "salesforce-events")
AZURE_PREFIX             = os.environ.get("AZURE_PREFIX", "platformevents")  # like a folder prefix

async def run():
    # Blob client
    blob_service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION)
    container = blob_service.get_container_client(AZURE_CONTAINER)
    try:
        container.create_container()
    except Exception:
        pass  # already exists

    # Salesforce Streaming API (CometD) client
    async with SalesforceStreamingClient(
        consumer_key=SF_CONSUMER_KEY,
        consumer_secret=SF_CONSUMER_SECRET,
        username=SF_USERNAME,
        password=SF_PASSWORD,
        domain=SF_DOMAIN
    ) as client:
        await client.subscribe(SF_CHANNEL)
        logging.info(f"✅ Subscribed to {SF_CHANNEL} on {SF_DOMAIN}")

        # Stream forever
        async for message in client:
            try:
                data = message.get("data", {})         # payload is under "data"
                name = f"{AZURE_PREFIX}/event-{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}.json"
                blob = container.get_blob_client(name)
                blob.upload_blob(json.dumps(data, default=str), overwrite=True)
                logging.info(f"📝 Wrote {name}")
            except Exception as e:
                logging.exception("Failed to write event")

if __name__ == "__main__":
    # auto-restart on crash
    while True:
        try:
            asyncio.run(run())
        except Exception:
            logging.exception("Subscriber crashed; restarting...")
